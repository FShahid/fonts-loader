﻿/*
 * Fonts Loader
 * 
 * Version: 1.0.0.3
 * 
 * Created by FShahid and TH3K31
 * 
 * For MiniTheatre.org
 * 
 * Date: 03/10/2012
 * 
 * Target Framework: .NET Framework 3.5
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace FontLoad
{
    public partial class Form1 : Form
    {
        [DllImport("gdi32.dll")]
        static extern int AddFontResource(string lpFilename);

        [DllImport("gdi32.dll")]
        static extern bool RemoveFontResource(string lpFileName);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern bool PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        private static IntPtr HWND_BROADCAST = new IntPtr(0xffff);
        const int WM_FONTCHANGE = 0x1D;

        static AutoResetEvent autoEvent = new AutoResetEvent(false);

        public int count = 0;
        public int total = 0;
        public string file = "";

        public Form1()
        {
            InitializeComponent();
            Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.High;
            this.Opacity = 0;
            this.Show();
            Application.DoEvents();
            for (float f = 0.0F; f < 0.94F; f = f + 0.12F)
            {
                this.Opacity = f;
                Thread.Sleep(20);
            }
            this.Opacity = 0.94;
            Thread t = new Thread(LoadFonts);
            t.Priority = ThreadPriority.Highest;
            t.Start();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback(Unload), autoEvent);
            autoEvent.WaitOne();
            base.OnFormClosing(e);
            if (e.CloseReason == CloseReason.WindowsShutDown) return;
            for (float f = 0.94F; f > 0.0F; f = f - 0.09F)
            {
                this.Opacity = f;
                Thread.Sleep(20);
            }
            this.Opacity = 0;
        }

        private void Unload(object stateInfo)
        {
            MinimizeBox = false;
            DirectoryInfo folder = new DirectoryInfo("Fonts");
            FileInfo[] fon = folder.GetFiles("*.fon");
            FileInfo[] fnt = folder.GetFiles("*.fnt");
            FileInfo[] ttc = folder.GetFiles("*.ttc");
            FileInfo[] ttf = folder.GetFiles("*.ttf");
            FileInfo[] fot = folder.GetFiles("*.fot");
            FileInfo[] otf = folder.GetFiles("*.otf");
            FileInfo[] mmm = folder.GetFiles("*.mmm");
            FileInfo[] pfb = folder.GetFiles("*.pfb");
            FileInfo[] pfm = folder.GetFiles("*.pfm");

            FileInfo[] allfonts = fon.Concat(fnt).ToArray();
            allfonts = allfonts.Concat(ttc).ToArray();
            allfonts = allfonts.Concat(ttf).ToArray();
            allfonts = allfonts.Concat(fot).ToArray();
            allfonts = allfonts.Concat(otf).ToArray();
            allfonts = allfonts.Concat(mmm).ToArray();
            allfonts = allfonts.Concat(pfb).ToArray();
            allfonts = allfonts.Concat(pfm).ToArray();

            try
            {
                foreach (FileInfo font in allfonts)
                {
                    file = font.Name;
                    RemoveFontResource(font.FullName);
                    PostMessage(HWND_BROADCAST, WM_FONTCHANGE, IntPtr.Zero, IntPtr.Zero);
                    count = count + 1;
                    if (count == 1)
                        label1.Text = "Unloaded " + count + " Font";
                    else
                        label1.Text = "Unloaded " + count + " Fonts";
                }
            }

            catch (Exception error)
            {
                MessageBox.Show(error.Message + "\n\nFileName: " + file, "Error While Unloading!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (total == 0)
                label1.Text = "Exiting...";
            else if (total == 1 && count == 1)
                label1.Text = "Font Unloaded!";
            else if (count == total)
                label1.Text = "All Fonts Unloaded!";
            Thread.Sleep(2000);
            ((AutoResetEvent)stateInfo).Set();
        }

        private void LoadFonts()
        {
            DirectoryInfo folder = new DirectoryInfo("Fonts");
            if (!folder.Exists)
            {
                label1.Text = "Fonts Not Found!";
                MessageBox.Show("Folder Not Found! Please Add Fonts In 'Fonts' Folder!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Directory.CreateDirectory("Fonts");
            }
            else
            {
                FileInfo[] fon = folder.GetFiles("*.fon");
                FileInfo[] fnt = folder.GetFiles("*.fnt");
                FileInfo[] ttc = folder.GetFiles("*.ttc");
                FileInfo[] ttf = folder.GetFiles("*.ttf");
                FileInfo[] fot = folder.GetFiles("*.fot");
                FileInfo[] otf = folder.GetFiles("*.otf");
                FileInfo[] mmm = folder.GetFiles("*.mmm");
                FileInfo[] pfb = folder.GetFiles("*.pfb");
                FileInfo[] pfm = folder.GetFiles("*.pfm");

                FileInfo[] allfonts = fon.Concat(fnt).ToArray();
                allfonts = allfonts.Concat(ttc).ToArray();
                allfonts = allfonts.Concat(ttf).ToArray();
                allfonts = allfonts.Concat(fot).ToArray();
                allfonts = allfonts.Concat(otf).ToArray();
                allfonts = allfonts.Concat(mmm).ToArray();
                allfonts = allfonts.Concat(pfb).ToArray();
                allfonts = allfonts.Concat(pfm).ToArray();

                try
                {
                    foreach (FileInfo font in allfonts)
                    {
                        file = font.Name;
                        AddFontResource(font.FullName);
                        PostMessage(HWND_BROADCAST, WM_FONTCHANGE, IntPtr.Zero, IntPtr.Zero);
                        count = count + 1;
                        if (count == 1)
                            label1.Text = "Loaded " + count + " Font";
                        else
                            label1.Text = "Loaded " + count + " Fonts";
                    }
                }

                catch (Exception error)
                {
                    MessageBox.Show(error.Message + "\n\nFileName: " + file, "Error While Loading!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (count == 0)
                    label1.Text = "Fonts Not Found!";
                else if (count == 1)
                {
                    label1.Text = "Loaded " + count + " Font!";
                    MinimizeBox = true;
                }
                else
                {
                    label1.Text = "Loaded " + count + " Fonts!";
                    MinimizeBox = true;
                }
                notifyIcon1.BalloonTipText = label1.Text;
                notifyIcon1.Text = "Fonts Loader - " + label1.Text;
                total = count;
                count = 0;
            }
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == this.WindowState)
            {
                notifyIcon1.Visible = true;
                this.ShowInTaskbar = false;
                this.Hide();
                notifyIcon1.ShowBalloonTip(500);
            }
        }

        private void notifyIcon1_MouseDoubleClick_1(object sender, MouseEventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
            this.ShowInTaskbar = true;
            notifyIcon1.Visible = false;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
            this.ShowInTaskbar = true;
            notifyIcon1.Visible = false;
            this.Close();
        }

        private void showWindowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
            this.ShowInTaskbar = true;
            notifyIcon1.Visible = false;
        }
    } 
}
